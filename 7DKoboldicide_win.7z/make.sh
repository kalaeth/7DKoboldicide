#!/bin/bash 
pyinstaller -D --clean -F -n 7DKoboldicide -c "7DKoboldicide.py"