
 If you need help figuring out what to do, find the forest (not the woods), and talk to the wise man!

-> keys :
	movement is orthogonal and performed with either of the following sets of keys :
		w,a,s,d 
		up, left, down, right
		keypad 8, keypad 4, keypad 2 and keypad 8
	keypad 5 and space both skip a turn

	the white dot in front of you is your aim, and the line above the game messages shows the things currently under it.

	'f' and keypad 9 will 'fight' the square you are currently aiming with whatever weapon happens to be in your right hand.
	  If you have no weapon you will still punch whatever stands before you, so don't start punching shopkeepers.
	 Go punch trees instead!

	'e' and keypad 7 are your action keys:
		- They pick things up (if you are on top of them or aiming at them)
		- They talk to people and kobolds 
		- They go up or down

	'q' and keypad 1  are for shooting. What will you shoot? Whatever equiped weapon capable of being shot you have. Of corse, if you throw your stick at the wall, you'll have to go and pick it up..

	'c' and keypad 3 call up the in-game menu (you can navigate it with the same kesy you move, select with action or fight keys and cancel with menu or shoot keys:
	 	-> inventory : allows you to see your stuff, switch things around (theoretically), (maybe) drop stuff
	 	-> drop stuff : for when you wish to drop stuff. really!
	 	-> char info : the only place where stats show up as numbers! I intend to change it.
	 	-> back to game : you could also press 'c' or keypad 3 or ESC or 'q' or keypad 9 to return to game.
	 	-> go back to the main menu. That kills the current game! Maybe I should add a confirmation.. [edit:done]

licences and legal stuffs!

for now:
you are free to copy, modify, distribute my game
you aren't allowed to sell it.
that covers most of it.

menu background from :
http://www.miniatures-workshop.com/lostminiswiki/index.php?title=KB_Series_-_Kobolds_(Otherworld)

thanks to Jotaf for the python+libtcod tutorial
